# 다른 컴퓨터에서 PDS 서버 관리하기

현재 적용 순서: 다른 PC·Mac의 SSH 키·방화벽 등록은 필요할 때까지 보류하고, 현재 Windows PC의 키로 Vultr 서버 구성을 이어간다. SSH는 Vultr와 NAS 모두에서 서버 관리에 쓰일 수 있다. Mac용 준비 도구는 보관만 하며 추가 PC 등록·실제 방화벽 변경은 실행하지 않았다.

Mac용 준비 도구다. Apple Silicon/Intel 모두 같은 Bash·OpenSSH 명령을 사용하도록 작성했다. 실제 Mac과 운영 서버에서의 확인은 아직 남아 있다. SSH 관리만 할 때 Homebrew·Docker·Java 설치는 필요 없다.

Windows 개인키를 복사하지 않고 각 PC에서 새 키를 만든다. 서버의 공개키 등록과 방화벽의 접속 IP 허용은 별개다. 서버의 앱·DB를 다시 설치할 필요는 없다.

## 1. Mac에서 준비

`pds-access-kit.zip`을 Mac으로 복사해서 압축을 푼다. 터미널에서 압축을 푼 폴더로 이동한다. 아래의 `macbook`은 이 PC를 구분할 이름이다.

```bash
bash pds-access.sh setup macbook
```

새 키의 암호를 묻는다. 기억할 수 있는 암호를 설정한다. 입력할 때 화면에 글자가 보이지 않는 것이 정상이다. 개인키는 `~/.ssh/pds/id_ed25519`에 보관된다. 기존 키가 있으면 덮어쓰지 않으며, 공개키와 지문이 일치하는지 확인한다.

등록할 공개키를 Mac 클립보드에 복사:

```bash
pbcopy < ~/.ssh/pds/id_ed25519.pub
```

서버 주소를 이미 안다면 최초 준비와 접속 설정을 한 번에 할 수 있다. `203.0.113.10`은 설명용 주소이므로 실제 서버 IPv4로 바꾼다.

```bash
bash pds-access.sh setup macbook 203.0.113.10
```

## 2. 최초 한 번, Mac 접속 허용

### 서버를 아직 만들지 않았다면

Vultr Account → SSH Keys에 이름 `pds-macbook`으로 공개키를 등록한다. 서버 생성 화면에서 사용할 PC들의 공개키를 선택하고 Limited User Login을 켠다.

### 이미 서버를 만들었다면

Mac의 공개키 한 줄과 PC 이름을 현재 작업에 전달하면 기존 관리자 접속으로 추가할 수 있다. 계정의 SSH Keys에 등록한 키는 실행 중인 서버에 자동 적용되지 않는다. 실행 서버의 Reinstall SSH Keys는 OS를 재설치하므로 사용하지 않는다.

직접 추가하거나 기존 SSH 접속이 막힌 경우를 위해 `setup`은 공개키만 포함한 `~/.ssh/pds/server-enroll.sh`도 만든다. 이 파일을 기존에 접속 가능한 PC를 통해 서버에 전달하거나 Vultr 웹 Console에서 내용을 파일로 저장한다. 파일 내용을 검토한 후 **등록 대상 계정인 linuxuser로** 실행한다.

```bash
bash /전달한/경로/server-enroll.sh
```

이 스크립트는 기존 `authorized_keys`를 백업한 뒤 공개키를 추가한다. 같은 키는 중복 추가하지 않으며, 이미 제한 옵션이 붙어 있는 같은 키의 제한도 유지한다. root로 실행하면 거부한다. 원격 서버에서 sudo로 실행하지 않는다. 웹 Console 로그인으로 root에 들어왔다면 먼저 `su - linuxuser`로 전환한다.

### 방화벽은 pds-web 하나를 계속 사용

Mac 브라우저에서 Vultr → Network → Firewall → **기존 pds-web** → Inbound IPv4 Rules로 이동한다.

| 항목 | 값 |
| --- | --- |
| Protocol / Port | TCP / 22 |
| Source | My IP — 현재 Mac 네트워크의 공인 IPv4 한 개(/32) |
| Note | 예: macbook-home |

기존 Windows의 22번 규칙을 남겨 두고 새 규칙을 **추가**한다. 같은 집/공유기라서 외부 IPv4가 같으면 규칙 하나를 공유해도 된다. 80/443 규칙은 공통으로 유지하고 DB·내부 API 포트는 열지 않는다. 그룹이 실제 서버에 연결되어 있는지도 확인한다.

Mac 터미널의 외부 IPv4와 추가할 규칙을 확인하려면:

```bash
bash pds-access.sh network
```

이 명령은 `https://api.ipify.org`에 읽기 요청 한 번을 보내 IPv4를 표시한다. 조회에 실패하면 화면의 My IP를 사용한다. VPN·프록시가 브라우저와 터미널에 다르게 적용되면 My IP와 SSH 출발 IP가 다를 수 있으므로 접속에 사용되는 네트워크 기준으로 허용한다.

## 3. 서버 주소 설정 후 접속

```bash
bash pds-access.sh configure cloud 203.0.113.10
bash pds-access.sh connect
```

주소는 실제 서버 IPv4로 바꾼다. 기본 사용자명은 `linuxuser`다. 실제 서버 사용자명이 다르면 configure 명령 마지막 인자로 지정한다.

기존 `~/.ssh/config`는 수정하지 않고 PDS 전용 설정을 `~/.ssh/pds/cloud.conf`에 저장한다. 도구 폴더 없이 직접 접속할 때도 다음 한 줄이면 된다.

```bash
ssh -F ~/.ssh/pds/cloud.conf pds-cloud
```

첫 접속에서는 Vultr 웹 Console에서 아래 명령으로 확인한 서버의 ED25519 지문과 SSH에 표시된 지문을 대조한 뒤 yes를 입력한다. 지문이 다르면 연결을 진행하지 않는다.

```bash
ssh-keygen -lf /etc/ssh/ssh_host_ed25519_key.pub
```

접속 없이 설정만 확인하는 명령은 `bash pds-access.sh check`다. 실제 접속 후에는 `whoami`와 `sudo -v`로 계정·관리 권한을 확인한다. 새 PC의 접속을 확인하기 전에는 기존 관리자 세션을 닫지 않는다.

## 4. 장소를 옮겼을 때

키를 다시 만들지 않는다. `network`로 IP를 확인하고 pds-web에 새 `/32` 규칙을 추가하면 된다. 새 연결을 확인한 뒤 더 이상 쓰지 않는 IP 규칙만 정리한다. SSH를 Anywhere로 바꾸지 않는다. IP를 자주 옮겨 이 절차가 번거로워지면 사설 관리 VPN 도입을 별도로 검토할 수 있으며 현재는 설치하지 않는다.

## 5. WTR로 이전할 때

WTR에도 각 PC의 공개키를 등록하고 WTR의 관리 접근 경로를 확인한다. 준비된 WTR IPv4를 아래 예시 주소 대신 입력한다. WTR의 실제 사용자명이 다르면 마지막 인자로 추가한다.

```bash
bash pds-access.sh configure wtr 192.168.1.50 linuxuser
bash pds-access.sh connect wtr
```

Vultr와 WTR 설정을 따로 보관한다. Vultr의 pds-web 방화벽 규칙이 WTR로 옮겨지는 것은 아니다. WTR의 로컬 방화벽과 원격 접속은 별도 검증 대상이다.

## 키를 잃어버렸거나 PC를 교체할 때

새 PC에서 새 키를 만들고 기존 관리자 또는 Vultr 웹 Console로 등록한다. 새 접속을 확인한 뒤 분실 PC의 공개키를 서버의 `authorized_keys`에서 제거한다. Vultr 계정의 키 목록에서 삭제하는 것만으로 실행 서버의 권한이 회수되지는 않는다. 마지막 정상 관리자 키를 먼저 삭제하지 않는다.

## 준비 완료와 실제 적용의 구분

이 ZIP에는 스크립트·설정 정책·안내만 들어 있다. 개인키·SMTP 비밀값·실제 서버 IP는 포함하지 않는다. 클라우드 방화벽·서버의 공개키는 이 도구를 Mac에서 실행하는 것만으로 자동 변경되지 않는다. 각 PC의 최초 공개키 등록과 네트워크 허용 후 반복 접속이 가능하다.

근거: [Vultr 기존 서버 키 추가·재설치 주의](https://docs.vultr.com/how-to-add-and-delete-ssh-keys), [Vultr 방화벽](https://docs.vultr.com/products/network/firewall-groups/management/rules), [OpenSSH 설정](https://man.openbsd.org/ssh_config), [OpenSSH 키 생성](https://man.openbsd.org/ssh-keygen).
