#!/bin/bash
# Run as the intended Linux login user, NOT with sudo. Accepts one public key.
set -euo pipefail
umask 077
fail() { printf 'Error: %s\n' "$*" >&2; exit 1; }
[ "$(id -u)" != 0 ] || fail 'Run as linuxuser (or the intended SSH user), not root.'
[ "$#" -eq 1 ] || fail 'Usage: bash add-public-key.sh "ssh-ed25519 AAAA... device-name"'
public_key=$1
[[ "$public_key" =~ ^ssh-ed25519\ [A-Za-z0-9+/=]+(\ [A-Za-z0-9._@-]+)?$ ]] || fail 'Expected one plain Ed25519 public key; options and multiline input are rejected.'
validation_file=$(mktemp)
cleanup() {
  [ -z "${validation_file:-}" ] || rm -f -- "$validation_file"
  [ -z "${replacement:-}" ] || rm -f -- "$replacement"
  [ -z "${held_lock:-}" ] || rmdir -- "$held_lock"
}
trap cleanup EXIT
printf '%s\n' "$public_key" > "$validation_file"
ssh-keygen -lf "$validation_file" >/dev/null || fail 'Invalid Ed25519 key data.'
blob=$(awk '{print $2}' "$validation_file")
ssh_dir="$HOME/.ssh"
authorized="$ssh_dir/authorized_keys"
[ ! -L "$ssh_dir" ] && [ ! -L "$authorized" ] || fail 'Refusing symbolic links in the SSH authorization path.'
mkdir -p "$ssh_dir"
chmod 700 "$ssh_dir"
mkdir "$ssh_dir/.pds-authorize.lock" || fail 'Another enrollment is running, or its lock needs inspection.'
held_lock="$ssh_dir/.pds-authorize.lock"
if [ -e "$authorized" ]; then
  [ -f "$authorized" ] || fail 'authorized_keys is not a regular file.'
  if awk -v key="$blob" '/^[[:space:]]*#/ { next } { for(i=1;i<NF;i++) if($i=="ssh-ed25519" && $(i+1)==key) found=1 } END { exit(found?0:1) }' "$authorized"; then
    printf 'Key already present. Existing content and restrictions preserved.\n'
    exit 0
  fi
fi
replacement=$(mktemp "$ssh_dir/.authorized_keys.new.XXXXXX")
if [ -f "$authorized" ]; then
  backup=$(mktemp "$ssh_dir/.authorized_keys.backup.XXXXXX")
  cp "$authorized" "$backup"
  chmod 600 "$backup"
  cat "$authorized" > "$replacement"
  # Ensure a key is never joined onto an existing line without a final newline.
  if [ -s "$authorized" ]; then printf '\n' >> "$replacement"; fi
  printf 'Existing keys backed up to %s\n' "$backup"
fi
printf '%s\n' "$public_key" >> "$replacement"
chmod 600 "$replacement"
mv "$replacement" "$authorized"
replacement=''
printf 'Public key added for %s. Test the new device before closing the current session.\n' "$(id -un)"
