#!/bin/bash
# macOS Bash 3.2 compatible. Local setup only; no Vultr API credentials.
set -euo pipefail
umask 077

fail() { printf 'Error: %s\n' "$*" >&2; exit 1; }
usage() {
  cat <<'HELP'
Usage:
  bash pds-access.sh setup DEVICE [SERVER_IPV4]
  bash pds-access.sh configure cloud|wtr SERVER_IPV4 [SSH_USER]
  bash pds-access.sh public-key
  bash pds-access.sh network
  bash pds-access.sh check [cloud|wtr]
  bash pds-access.sh connect [cloud|wtr]

Example: bash pds-access.sh setup macbook 203.0.113.10
Use your actual server IP. A new key prompts for a passphrase.
HELP
}
valid_ipv4() {
  case "$1" in *$'\n'*|*$'\r'*) return 1 ;; esac
  printf '%s\n' "$1" | awk -F. '
    NF != 4 { exit 1 }
    { for(i=1;i<=4;i++) if($i !~ /^[0-9]+$/ || length($i)>3 || $i+0>255 || (length($i)>1 && substr($i,1,1)=="0")) exit 1 }
    $1+0 == 0 || $1+0 >= 224 { exit 1 }
  '
}
safe_path() { [ ! -L "$1" ] || fail "Refusing symbolic link: $1"; }
prepare_dir() {
  safe_path "$HOME/.ssh"; safe_path "$access_dir"
  mkdir -p "$access_dir"
  chmod 700 "$HOME/.ssh" "$access_dir"
}
require_key() {
  safe_path "$HOME/.ssh"; safe_path "$access_dir"; safe_path "$key"; safe_path "$key.pub"
  [ -s "$key" ] && [ -s "$key.pub" ] || fail 'Run setup first.'
  local private_fp public_fp
  private_fp=$(ssh-keygen -lf "$key" | awk '{print $2}')
  public_fp=$(ssh-keygen -lf "$key.pub" | awk '{print $2}')
  [ "$private_fp" = "$public_fp" ] || fail 'Private/public key mismatch; existing files were preserved.'
}
configure() {
  local target=$1 ip=$2 account=$3 config tmp
  case "$target" in cloud|wtr) ;; *) fail 'Target must be cloud or wtr.' ;; esac
  valid_ipv4 "$ip" || fail 'Supply one IPv4 address, without a port or /32.'
  [[ "$account" =~ ^[a-z_][a-z0-9_-]*$ ]] || fail 'Invalid SSH user.'
  prepare_dir; require_key
  config="$access_dir/$target.conf"
  safe_path "$config"; safe_path "$config.previous"; safe_path "$access_dir/known_hosts"
  if [ -e "$config" ]; then
    grep -qxF '# PDS managed SSH configuration v1' "$config" || fail "Unmanaged file: $config"
  fi
  tmp=$(mktemp "$access_dir/.config.XXXXXX")
  cat > "$tmp" <<CONFIG
# PDS managed SSH configuration v1
Host pds-$target
    HostName $ip
    User $account
    Port 22
    AddressFamily inet
    IdentityFile "~/.ssh/pds/id_ed25519"
    IdentitiesOnly yes
    StrictHostKeyChecking ask
    HostKeyAlgorithms ssh-ed25519
    UserKnownHostsFile "~/.ssh/pds/known_hosts"
    AddKeysToAgent yes
    ForwardAgent no
    ServerAliveInterval 30
    ServerAliveCountMax 3
CONFIG
  chmod 600 "$tmp"
  if [ -f "$config" ]; then cp -p "$config" "$config.previous"; fi
  mv "$tmp" "$config"
  printf 'Saved %s. Connect: bash pds-access.sh connect %s\n' "$config" "$target"
}

[ -n "${HOME:-}" ] && [ -d "$HOME" ] || fail 'HOME must be an existing directory.'
access_dir="$HOME/.ssh/pds"
key="$access_dir/id_ed25519"
script_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
command=${1:-help}
case "$command" in
  setup)
    [ "$#" -ge 2 ] && [ "$#" -le 3 ] || { usage; exit 1; }
    device=$2
    [[ "$device" =~ ^[a-zA-Z0-9][a-zA-Z0-9_-]*$ ]] && [ "${#device}" -le 40 ] || fail 'DEVICE: use 1-40 letters, digits, - or _.'
    if [ "$#" -eq 3 ]; then valid_ipv4 "$3" || fail 'Invalid server IPv4.'; fi
    prepare_dir
    safe_path "$key"; safe_path "$key.pub"; safe_path "$access_dir/device"
    if [ -f "$access_dir/device" ]; then
      [ "$(cat "$access_dir/device")" = "$device" ] || fail 'This installation already belongs to a different DEVICE label.'
    fi
    if [ ! -e "$key" ]; then
      [ ! -e "$key.pub" ] || fail 'Orphan public key exists; inspect it before creating another key.'
      ssh-keygen -t ed25519 -a 64 -C "pds-$device" -f "$key"
    fi
    require_key
    chmod 600 "$key" "$key.pub"
    printf '%s\n' "$device" > "$access_dir/device"
    safe_path "$access_dir/server-enroll.sh"
    tmp=$(mktemp "$access_dir/.enroll.XXXXXX")
    # %q safely encodes the public key as one Bash argument. No private key is read.
    { printf '#!/bin/bash\nset -- %q\n' "$(cat "$key.pub")"; cat "$script_dir/add-public-key.sh"; } > "$tmp"
    chmod 600 "$tmp"
    mv "$tmp" "$access_dir/server-enroll.sh"
    printf '\nPublic key (register this key for this device):\n'
    cat "$key.pub"
    ssh-keygen -lf "$key.pub"
    printf '\nPublic enrollment script: %s/server-enroll.sh\n' "$access_dir"
    if [ "$#" -eq 3 ]; then configure cloud "$3" linuxuser; fi
    printf 'Next: register this public key on the server and add your IPv4 /32 to pds-web TCP 22.\n'
    ;;
  configure)
    [ "$#" -ge 3 ] && [ "$#" -le 4 ] || { usage; exit 1; }
    configure "$2" "$3" "${4:-linuxuser}"
    ;;
  public-key)
    require_key; cat "$key.pub"
    ;;
  network)
    # Explicit read-only request; output is not saved or sent to Vultr/Notion.
    ip=$(curl -4 --fail --silent --show-error --connect-timeout 5 --max-time 10 https://api.ipify.org) || fail 'IP lookup failed. Use My IP in the Vultr firewall page.'
    valid_ipv4 "$ip" || fail 'IP service returned an invalid address.'
    printf 'Vultr group: pds-web\nProtocol: TCP\nPort: 22\nSource: %s/32\nKeep existing authorized PC rules. Web 80/443 rules stay unchanged.\n' "$ip"
    ;;
  check|connect)
    target=${2:-cloud}
    case "$target" in cloud|wtr) ;; *) fail 'Target must be cloud or wtr.' ;; esac
    require_key; safe_path "$access_dir/$target.conf"; safe_path "$access_dir/known_hosts"
    [ -f "$access_dir/$target.conf" ] || fail 'Run configure for this target first.'
    if [ "$command" = check ]; then
      exec ssh -G -F "$access_dir/$target.conf" "pds-$target"
    fi
    exec ssh -F "$access_dir/$target.conf" "pds-$target"
    ;;
  help|--help|-h) usage ;;
  *) usage; exit 1 ;;
esac
